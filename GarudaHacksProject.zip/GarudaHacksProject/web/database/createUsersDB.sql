CREATE TABLE "USERS"
(
"username" VARCHAR (255) primary key not null,   
"email" VARCHAR (128) primary key not null,
"password" VARCHAR (128) primary key not null,
)
